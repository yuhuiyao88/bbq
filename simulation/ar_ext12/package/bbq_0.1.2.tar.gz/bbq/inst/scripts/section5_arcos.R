# Reproduces Section 5 (Illustration) of the BBQ manuscript: daily oxycodone
# shipments into Alabama, 2015-2019 (ARCOS).
#
#   Rscript section5_arcos.R            # final fit at the reported configuration
#   BBQ_TUNE=1 Rscript section5_arcos.R # also rerun the Section 2.5 cross-validation
#
# Figures and a results table are written to ./output. Needs ggplot2 and
# changepoint (the binary segmentation comparator); the tuning run is long.
suppressPackageStartupMessages(library(bbq))
out <- Sys.getenv("BBQ_OUTPUT", "output")
dir.create(out, showWarnings = FALSE, recursive = TRUE)
seed <- 1

data(arcos_al)
x <- arcos_al$mme_per_capita
dates <- arcos_al$date

## ---- Data description (Figures 3-5) ----
res <- list(
  T = length(x), zero_days = sum(x == 0), mean = mean(x), median = median(x), max = max(x),
  saturday = mean(x[arcos_al$weekday == 7]), sunday = mean(x[arcos_al$weekday == 1]),
  holidays = sum(arcos_al$holiday == 1), holiday_mean = mean(x[arcos_al$holiday == 1]),
  nonholiday_mean = mean(x[arcos_al$holiday == 0]),
  acf7_raw = stats::acf(x, lag.max = 7, plot = FALSE)$acf[8])
y <- as.numeric(residuals(lm(mme_per_capita ~ holiday + factor(weekday), data = arcos_al)))
res$acf7_resid <- stats::acf(y, lag.max = 7, plot = FALSE)$acf[8]
res$pacf1_resid <- stats::pacf(y, lag.max = 1, plot = FALSE)$acf[1]
res$ljung_box_14 <- unname(stats::Box.test(y, lag = 14, type = "Ljung-Box")$statistic)
m3 <- mean((y - mean(y))^3); m2 <- mean((y - mean(y))^2); m4 <- mean((y - mean(y))^4)
res$resid_skewness <- m3 / m2^1.5
res$resid_kurtosis <- m4 / m2^2

grDevices::png(file.path(out, "figure3_series.png"), width = 1600, height = 600, res = 150)
plot(dates, x, type = "l", xlab = "date", ylab = "MME per capita")
grDevices::dev.off()
grDevices::png(file.path(out, "figure4_weekday_holiday.png"), width = 1600, height = 600, res = 150)
graphics::par(mfrow = c(1, 2))
graphics::boxplot(x ~ factor(arcos_al$weekday, 1:7, c("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")),
                  xlab = "day of week", ylab = "MME per capita")
graphics::boxplot(x ~ factor(arcos_al$holiday, 0:1, c("other", "holiday")), xlab = "", ylab = "MME per capita")
grDevices::dev.off()
grDevices::png(file.path(out, "figure5_acf_pacf.png"), width = 1600, height = 1200, res = 150)
graphics::par(mfrow = c(2, 2))
stats::acf(x, main = "series"); stats::pacf(x, main = "series")
stats::acf(y, main = "residuals"); stats::pacf(y, main = "residuals")
grDevices::dev.off()

## ---- Design, tuning and final fit (Sections 2.5 and 5) ----
l <- 30; w <- 90
prior <- "spike_slab_lasso"
if (nzchar(Sys.getenv("BBQ_TUNE"))) {
  cv <- bbqTune(y, l, w, prior = prior, seed = seed, verbose = TRUE)
  utils::write.csv(cv, file.path(out, "section5_cv.csv"), row.names = FALSE)
  lambda_iq <- cv$lambda_iq[1]; spike_sd <- cv$spike_sd[1]
} else {
  lambda_iq <- 100; spike_sd <- 0.1        # the configuration reported in Section 5
}
fit <- bbqFit(y, l, w, prior = prior, lambda_iq = lambda_iq, shrinkage = spike_sd, seed = seed)
det <- bbqDetect(fit, l, w)

## ---- Detection results (Figures 6-8 and the text of Section 5) ----
qs <- det$tests$qss; ooc <- qs$ui$raw; cells <- qs$ui$cells$raw; zt <- qs$z_white
blk <- det$detected_blocks
eta <- getEta(fit, seed = seed)
prof <- getQSS(eta)
med <- colMeans(prof[, 1, ]); iqr <- colMeans(prof[, 2, ])
n <- length(y); last90 <- (n - 89):n
cp <- changepoint::cpts(changepoint::cpt.meanvar(y, method = "BinSeg", Q = ncol(fit$H),
                                                 minseglen = l, penalty = "Asymptotic",
                                                 pen.value = 0.05))
in_ooc <- vapply(cp, function(t) any(t >= blk$obs_start[ooc] & t <= blk$obs_end[ooc]), TRUE)
res <- c(res, list(
  l = l, w = w, r = ncol(fit$H), prior = prior, spike_sd = spike_sd, lambda_iq = lambda_iq,
  qss_blocks = length(ooc), quantile_blocks = length(det$tests$quantile$ui$raw),
  overall_ui_p_quantile = det$tests$quantile$overall_ui_p, overall_ui_p_qss = qs$overall_ui_p,
  first_flagged_block = format(dates[blk$obs_start[min(ooc)]]),
  last_flagged_block = format(dates[blk$obs_start[max(ooc)]]),
  first_localized_cp = format(dates[blk$signal_obs[min(ooc)]]),
  location_cells = sum(cells["LS", ]), location_cells_neg = sum(cells["LS", ] & zt["LS", ] < 0),
  scale_cells = sum(cells["ScS", ]), scale_cells_neg = sum(cells["ScS", ] & zt["ScS", ] < 0),
  scale_cells_pos = sum(cells["ScS", ] & zt["ScS", ] > 0),
  median_warmup = mean(med[1:w]), median_last90 = mean(med[last90]),
  iqr_warmup = mean(iqr[1:w]), iqr_last90 = mean(iqr[last90]),
  iqr_min_month = format(dates[which.min(iqr)], "%Y-%m"),
  binseg_cps = length(cp), binseg_in_flagged_blocks = sum(in_ooc)))
tab <- data.frame(quantity = names(res),
                  value = vapply(res, function(v) if (is.numeric(v)) format(signif(v, 4)) else as.character(v), ""))
utils::write.csv(tab, file.path(out, "section5_results.csv"), row.names = FALSE)
print(tab, row.names = FALSE)

if (requireNamespace("ggplot2", quietly = TRUE)) {
  p6 <- plotQuantileProcess(fit, time = dates, detection = det, basis = "qss",
                            comparator = cp, comparator_label = "BinSeg",
                            proposed_label = "Proposed (BBQ)", ylab = "residual")
  p7 <- plotQSSProcess(fit, eta = eta, time = dates, detection = det, basis = "qss")
  p8 <- plotGammaHeatmap(fit, detection = det, basis = "qss",
                         block_labels = format(dates[blk$obs_start]))
  ggplot2::ggsave(file.path(out, "figure6_quantile_process.png"), p6, width = 10, height = 4.5, dpi = 200)
  ggplot2::ggsave(file.path(out, "figure7_qss_profile.png"), p7, width = 10, height = 5, dpi = 200)
  ggplot2::ggsave(file.path(out, "figure8_qss_heatmap.png"), p8, width = 12, height = 3.5, dpi = 200)
}
writeLines(capture.output(sessionInfo()), file.path(out, "section5_sessionInfo.txt"))
